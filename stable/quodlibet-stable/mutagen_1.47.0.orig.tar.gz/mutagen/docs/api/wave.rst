WAVE
----

.. automodule:: mutagen.wave

.. autoclass:: mutagen.wave.WAVE(filename)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.wave.WaveStreamInfo()
    :members:
