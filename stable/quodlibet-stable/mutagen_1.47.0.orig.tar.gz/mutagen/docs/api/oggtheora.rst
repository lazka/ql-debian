Ogg Theora
==========

.. automodule:: mutagen.oggtheora

.. autoclass:: mutagen.oggtheora.OggTheora
    :show-inheritance:
    :members:

.. autoclass:: mutagen.oggtheora.OggTheoraInfo
    :show-inheritance:
    :members:
