AC3
===

.. automodule:: mutagen.ac3

.. autoexception:: mutagen.ac3.AC3Error

.. autoclass:: mutagen.ac3.AC3(filename)
    :show-inheritance:
    :members:

.. autoclass:: mutagen.ac3.AC3Info()
    :show-inheritance:
    :members:
