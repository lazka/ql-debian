WavPack
=======

.. automodule:: mutagen.wavpack

.. autoclass:: mutagen.wavpack.WavPack
    :show-inheritance:
    :members:

.. autoclass:: mutagen.wavpack.WavPackInfo
    :members:
