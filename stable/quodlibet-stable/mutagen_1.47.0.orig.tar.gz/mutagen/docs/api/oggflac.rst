Ogg FLAC
========

.. automodule:: mutagen.oggflac

.. autoclass:: mutagen.oggflac.OggFLAC
    :show-inheritance:

.. autoclass:: mutagen.oggflac.OggFLACStreamInfo
    :show-inheritance:
    :members:
