==========
User Guide
==========

.. toctree::
    :titlesonly:
    :maxdepth: 2

    gettingstarted
    classes
    filelike
    padding

    id3
    vcomment
    apev2
    mp4
