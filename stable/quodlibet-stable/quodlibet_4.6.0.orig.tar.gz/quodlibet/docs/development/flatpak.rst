Flatpak
=======

To share the config between the distro package/development environment and the
flatpak symlink the config directory::

    ln -s ~/.config/quodlibet ~/.var/app/io.github.quodlibet.QuodLibet/config

Our official flatpak is hosted on Flathub:

    https://github.com/flathub/io.github.quodlibet.QuodLibet
