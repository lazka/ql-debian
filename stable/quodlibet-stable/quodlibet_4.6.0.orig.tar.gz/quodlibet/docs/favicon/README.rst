The svg is based on
``quodlibet/images/hicolor/scalable/apps/quodlibet-symbolic.svg``
