.. _Podcasts:

Podcasts Browser
----------------

The *Podcasts* browser allows you to subscribe to podcasts
(syndicated feeds with attached audio files).

Feeds are automatically checked for updates every two hours,
and emboldened if new entries are found.

You can right-click on a file in an audio feed, and select *Download file*,
to download it to your hard drive.
Note the browser is for the remote file,
so changes to the downloaded file will not be reflected in the browser.
