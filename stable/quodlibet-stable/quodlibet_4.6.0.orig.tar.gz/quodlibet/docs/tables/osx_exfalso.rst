.. list-table::
    :header-rows: 1

    * - Release
      - File
      - SHA256
      - PGP
    * - Ex Falso 4.4.0
      - `ExFalso-4.4.0.dmg <https://github.com/quodlibet/quodlibet/releases/download/release-4.4.0/ExFalso-4.4.0.dmg>`__
      - `SHA256 <https://github.com/quodlibet/quodlibet/releases/download/release-4.4.0/ExFalso-4.4.0.dmg.sha256>`__
      - `SIG <https://github.com/quodlibet/quodlibet/releases/download/release-4.4.0/ExFalso-4.4.0.dmg.sig>`__
    * - Ex Falso 4.3.0
      - `ExFalso-4.3.0.dmg <https://github.com/quodlibet/quodlibet/releases/download/release-4.3.0/ExFalso-4.3.0.dmg>`__
      - `SHA256 <https://github.com/quodlibet/quodlibet/releases/download/release-4.3.0/ExFalso-4.3.0.dmg.sha256>`__
      - `SIG <https://github.com/quodlibet/quodlibet/releases/download/release-4.3.0/ExFalso-4.3.0.dmg.sig>`__
    * - Ex Falso 4.2.1
      - `ExFalso-4.2.1.dmg <https://github.com/quodlibet/quodlibet/releases/download/release-4.2.1/ExFalso-4.2.1.dmg>`__
      - `SHA256 <https://github.com/quodlibet/quodlibet/releases/download/release-4.2.1/ExFalso-4.2.1.dmg.sha256>`__
      - `SIG <https://github.com/quodlibet/quodlibet/releases/download/release-4.2.1/ExFalso-4.2.1.dmg.sig>`__
