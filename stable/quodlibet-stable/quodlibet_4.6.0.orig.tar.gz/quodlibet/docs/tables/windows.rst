.. list-table::
    :header-rows: 1

    * - Release
      - File
      - SHA256
      - PGP
    * - Quod Libet 4.5.0
      - `quodlibet-4.5.0-installer.exe <https://github.com/quodlibet/quodlibet/releases/download/release-4.5.0/quodlibet-4.5.0-installer.exe>`__
      - `SHA256 <https://github.com/quodlibet/quodlibet/releases/download/release-4.5.0/quodlibet-4.5.0-installer.exe.sha256>`__
      - `SIG <https://github.com/quodlibet/quodlibet/releases/download/release-4.5.0/quodlibet-4.5.0-installer.exe.sig>`__
    * - Quod Libet 4.4.0
      - `quodlibet-4.4.0-installer.exe <https://github.com/quodlibet/quodlibet/releases/download/release-4.4.0/quodlibet-4.4.0-installer.exe>`__
      - `SHA256 <https://github.com/quodlibet/quodlibet/releases/download/release-4.4.0/quodlibet-4.4.0-installer.exe.sha256>`__
      - `SIG <https://github.com/quodlibet/quodlibet/releases/download/release-4.4.0/quodlibet-4.4.0-installer.exe.sig>`__
    * - Quod Libet 4.3.0
      - `quodlibet-4.3.0-installer.exe <https://github.com/quodlibet/quodlibet/releases/download/release-4.3.0/quodlibet-4.3.0-installer.exe>`__
      - `SHA256 <https://github.com/quodlibet/quodlibet/releases/download/release-4.3.0/quodlibet-4.3.0-installer.exe.sha256>`__
      - `SIG <https://github.com/quodlibet/quodlibet/releases/download/release-4.3.0/quodlibet-4.3.0-installer.exe.sig>`__
