.. list-table::
    :header-rows: 1

    * - Release
      - File
      - SHA256
      - PGP
    * - Quod Libet 4.4.0
      - `QuodLibet-4.4.0.dmg <https://github.com/quodlibet/quodlibet/releases/download/release-4.4.0/QuodLibet-4.4.0.dmg>`__
      - `SHA256 <https://github.com/quodlibet/quodlibet/releases/download/release-4.4.0/QuodLibet-4.4.0.dmg.sha256>`__
      - `SIG <https://github.com/quodlibet/quodlibet/releases/download/release-4.4.0/QuodLibet-4.4.0.dmg.sig>`__
    * - Quod Libet 4.3.0
      - `QuodLibet-4.3.0.dmg <https://github.com/quodlibet/quodlibet/releases/download/release-4.3.0/QuodLibet-4.3.0.dmg>`__
      - `SHA256 <https://github.com/quodlibet/quodlibet/releases/download/release-4.3.0/QuodLibet-4.3.0.dmg.sha256>`__
      - `SIG <https://github.com/quodlibet/quodlibet/releases/download/release-4.3.0/QuodLibet-4.3.0.dmg.sig>`__
    * - Quod Libet 4.2.1
      - `QuodLibet-4.2.1.dmg <https://github.com/quodlibet/quodlibet/releases/download/release-4.2.1/QuodLibet-4.2.1.dmg>`__
      - `SHA256 <https://github.com/quodlibet/quodlibet/releases/download/release-4.2.1/QuodLibet-4.2.1.dmg.sha256>`__
      - `SIG <https://github.com/quodlibet/quodlibet/releases/download/release-4.2.1/QuodLibet-4.2.1.dmg.sig>`__
