.. _license:

License & Contributors
======================

License
-------

Quod Libet and all associated modules are free software distributed entirely
under the terms of the `GNU GPL version 2 or later
<https://www.gnu.org/licenses/old-licenses/gpl-2.0.html>`__. Alternate
licensing terms such as MIT, BSD or LGPL may be available for certain files or
modules; see the files for details.


Authors
^^^^^^^

.. contributors:: authors

Translators
^^^^^^^^^^^

.. contributors:: translators

Artists
^^^^^^^

.. contributors:: artists
