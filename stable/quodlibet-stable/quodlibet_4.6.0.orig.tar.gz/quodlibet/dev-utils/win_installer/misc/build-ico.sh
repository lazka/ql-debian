#!/bin/bash

set -e

convert ../../../quodlibet/images/hicolor/*/apps/io.github.quodlibet.QuodLibet.png quodlibet.ico
convert ../../../quodlibet/images/hicolor/*/apps/io.github.quodlibet.ExFalso.png exfalso.ico
