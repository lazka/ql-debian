==============================
Quod Libet / Ex Falso Portable
==============================

Content
-------

* 'config' contains all user configuration and the song database
* 'data' contains the program
* The links, quodlibet and exfalso, point to data/bin/<name>.exe


How to update to a newer version?
---------------------------------

1) Download and extract the new version
2) Replace the 'config' folder in the new version with the 'config' folder
   of the older version.
