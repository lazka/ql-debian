This contains all the input for gtk-mac-bundler and the launcher script which
is the entry point in each app bundle and responsible for setting up the
environment.

The icons are created from SVGs using the ../build_icns.sh script
