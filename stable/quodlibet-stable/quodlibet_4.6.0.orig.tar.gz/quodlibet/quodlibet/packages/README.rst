Don't change anything here as these are just copies of upstream releases.

senf:
    PYPI: https://pypi.python.org/pypi/senf
    License: "MIT License"

raven:
    PYPI: https://pypi.python.org/pypi/raven
    License: "BSD 3-Clause License"
