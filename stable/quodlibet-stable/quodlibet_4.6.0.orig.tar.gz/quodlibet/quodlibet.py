#!/usr/bin/env python3
# Copyright 2016 Christoph Reiter
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

import sys

from quodlibet.main import main

if __name__ == "__main__":
    sys.exit(main())
